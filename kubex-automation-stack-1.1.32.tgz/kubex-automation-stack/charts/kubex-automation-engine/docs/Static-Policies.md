# Static Policies

Static policies apply explicit request and limit values to matching workloads.

Use them when you want deterministic resource values instead of recommendation-driven sizing.

## Scope Mapping

- `StaticPolicy` is namespaced and references an `AutomationStrategy` in the same namespace.
- `ClusterStaticPolicy` is cluster-scoped and references a `ClusterAutomationStrategy`.

## Field Reference

## `StaticPolicy.spec`

| Field | Default | Description |
| --- | --- | --- |
| `spec.scope` | none | Optional scope object for workload selection in the same namespace. |
| `spec.scope.labelSelector` | none | Kubernetes label selector for matching workloads. |
| `spec.scope.workloadTypes` | `[Deployment, StatefulSet, CronJob, Rollout, Job, AnalysisRun, DaemonSet, Model]` | Workload kinds this policy applies to. Default excludes `StrimziPodSet` only. |
| `spec.scope.containers` | all automatable containers | Exact container names. Duplicates, `"*"`, and invalid Kubernetes container names are rejected. Unknown names are allowed. |
| `spec.resources.containers` | none | Map of container names to requests and limits. Use `"*"` for all scoped containers. |
| `spec.weight` | `0` | Higher weight takes precedence when same-kind policies compete. |
| `spec.automationStrategyRef.name` | none | Required namespaced strategy name. |

## `ClusterStaticPolicy.spec`

| Field | Default | Description |
| --- | --- | --- |
| `spec.scope.labelSelector` | none | Kubernetes label selector for matching workloads. |
| `spec.scope.workloadTypes` | `[Deployment, StatefulSet, CronJob, Rollout, Job, AnalysisRun, DaemonSet, Model]` | Workload kinds this policy applies to. Default excludes `StrimziPodSet` only. |
| `spec.scope.namespaceSelector.operator` | none | Namespace selector operator: `In` or `NotIn`. |
| `spec.scope.namespaceSelector.values` | none | Namespace patterns to include or exclude (supports `*` wildcards, e.g. "prod-*"). Wildcard patterns must be enclosed in double quotes. |
| `spec.scope.containers` | all automatable containers | Exact container names. Empty means all automatable containers. |
| `spec.resources.containers` | none | Map of container names to requests and limits. Use `"*"` for all scoped containers. |
| `spec.weight` | `0` | Higher weight takes precedence when same-kind policies compete. |
| `spec.automationStrategyRef.name` | none | Required cluster strategy name. |

## Example: Namespaced Static Policy

```yaml
apiVersion: rightsizing.kubex.ai/v1alpha1
kind: StaticPolicy
metadata:
  name: team-a-fixed-resources
  namespace: team-a
spec:
  scope:
    containers:
      - api
      - metrics
    labelSelector:
      matchLabels:
        app.kubernetes.io/part-of: storefront
      matchExpressions:
        - key: tier
          operator: In
          values:
            - api
            - worker
    workloadTypes:
      - Deployment
      - StatefulSet
  resources:
    containers:
      "*":
        requests:
          cpu: "250m"
          memory: "512Mi"
        limits:
          cpu: "1"
          memory: "1Gi"
      api:
        requests:
          cpu: "500m"
          memory: "1Gi"
        limits:
          cpu: "2"
          memory: "2Gi"
  weight: 100
  automationStrategyRef:
    name: team-a-balanced
```

## Example: Cluster Static Policy

```yaml
apiVersion: rightsizing.kubex.ai/v1alpha1
kind: ClusterStaticPolicy
metadata:
  name: platform-database-baseline
spec:
  scope:
    labelSelector:
      matchLabels:
        tier: database
    workloadTypes:
      - StatefulSet
    namespaceSelector:
      operator: In
      values:
        - "prod-*"
        - shared-services
  resources:
    containers:
      postgres:
        requests:
          cpu: "1"
          memory: "2Gi"
        limits:
          cpu: "2"
          memory: "4Gi"
      metrics:
        requests:
          cpu: "200m"
          memory: "256Mi"
        limits:
          cpu: "500m"
          memory: "512Mi"
  weight: 200
  automationStrategyRef:
    name: platform-conservative
```

## Notes

- Use static policies when exact values matter more than recommendation-driven tuning.
- `resources.containers."*"` applies a default to every scoped container, and named values override wildcard values for the same resource.
- When `scope.containers` is set, entries for other containers are removed and wildcard values expand into each listed name.
- Container targets include regular containers and native sidecar init containers (`restartPolicy: Always`). One-shot init containers are not automated.
- `Model` is included in default workload types. Use `spec.scope.workloadTypes: [Model]` when you want to restrict scope to KubeAI `Model` objects only. Recommendations and rollback state are stored on the `Model` owner, then inherited by model-owned pods.
- By default, only one same-kind static policy contributes to a workload. With `globalConfiguration.multiPolicyContainerRightsizingEnabled: true`, separate container/resource targets can come from different policies; `PolicyEvaluation` resolves overlapping targets. See [Multi-Policy Container Rightsizing](./Multi-Policy-Container-Rightsizing.md).
