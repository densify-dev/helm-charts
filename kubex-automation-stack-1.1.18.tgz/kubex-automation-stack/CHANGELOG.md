# Changelog

All notable changes to the kubex-automation-stack chart will be documented in this file.

## [1.1.18] - 2026-09-24

### Changed
- Updated kubex-connector and kubex-ai-cdi dependencies to 1.6.0.

---

## [1.1.17] - 2026-09-23

### Changed
- Updated kubex-automation-engine dependency to 1.14.0.

---

## [1.1.16] - 2026-09-17

### Changed
- Updated kubex-connector and kubex-ai-cdi dependencies to 1.5.0.

---

## [1.1.15] - 2026-09-16

### Changed
- Updated kubex-automation-engine dependency to 1.13.2.

---

## [1.1.14] - 2026-09-15

### Changed
- Updated kubex-automation-engine dependency to 1.13.1.

---

## [1.1.13] - 2026-09-14

### Changed
- Updated kubex-automation-engine dependency to 1.13.0.

---

## [1.1.12] - 2026-09-11

### Changed
- Fixed the JVM regex to accommodate an additional metric.

---

## [1.1.11] - 2026-09-10

### Changed
- Added app-specific scrape configs for JVM and vLLM workloads.

---

## [1.1.10] - 2026-09-10

### Changed
- Added cluster-size resource settings for k8s-ephemeral-storage-metrics.
- Updated kubex-connector dependency to 1.4.0.
- Updated kubex-ai-cdi dependency to 1.4.0.
- Updated kubex-automation-engine dependency to 1.12.0.

---

## [1.1.9] - 2026-09-10

### Changed
- Fixed default subchart names so release resources no longer use `kubex-kubex-*` names.
- Changed the default stack-managed CDI ClusterRole and ClusterRoleBinding suffix to `ai-cdi-reader`.

---

## [1.1.8] - 2026-09-01

### Changed
- Enabled the stack-managed connector and CDI components by default.

---

## [1.1.7] - 2026-08-31

### Changed
- Updated gpu-process-exporter dependency to 1.1.4.

---

## [1.1.6] - 2026-08-28

### Changed
- Updated kubex-automation-engine dependency to 1.11.2.

---

## [1.1.5] - 2026-08-27

### Changed
- Updated kubex-automation-engine dependency to 1.11.1.

---

## [1.1.3] - 2026-08-20

### Changed
- Updated kubex-connector dependency to 1.2.0.
- Updated kubex-ai-cdi dependency to 1.2.0.

---

## [1.1.2] - 2026-08-20

### Changed
- Updated kubex-automation-engine dependency to 1.11.0.

---

## [1.1.1] - 2026-08-20

### Changed
- Updated gpu-process-exporter dependency to 1.1.2.

---

## [1.1.0] - 2026-08-19

### Added
- Added documentation for custom container CPU and memory metrics
- Added optional kubex-automation-engine as a dependency for automated workload rightsizing
  - Disabled by default to maintain backward compatibility with existing standalone installations
  - Shares Kubex credentials with the automation engine
  - Shares cluster configuration (cluster name and Kubex instance URL) with other stack components
  - Sources automation-engine `CLUSTER_NAME` from the stack-managed runtime ConfigMap via `kubex.clusterNameFrom`
- Added comprehensive documentation for enabling and configuring the automation engine
- Updated README with installation instructions and migration guidance

### Changed
- Added the URL configuration required for kubex-automation-engine compatibility
- Renamed the stack runtime ConfigMap from `kubex-connector-runtime` to `kubex-stack-runtime`
- Updated stack-managed connector, CDI, and automation-engine defaults to consume `kubex-stack-runtime`
- Removed the YAML anchor requirement from `values-edit.yaml` and README for automation-engine enablement

## [1.0.22] - 2026-08-12

### Added
- Added optional connector and CDI support to the stack
- Added stack-managed CDI access and shared cluster identity configuration

### Changed
- Updated connector and CDI dependencies to 1.1.1
- Added connector, relay, and CDI resource sizing to each cluster-size values overlay
- Updated OpenShift support for the connector and CDI components


## [1.0.20] - 2026-08-07

### Changed
- Updated Prometheus chart dependency from v29.14.0 to v29.21.0
- Updated Beyla chart dependency from v1.16.8 to v1.16.10
- Updated gpu-process-exporter dependency from v1.1.0 to v1.1.1
  - Updated values schema to include new scheduling configuration options

## [1.0.19] - 2026-07-14

### Added
- Added RBAC Guide documentation for all components installed in the helm chart

### Changed
- Added `kubernetes.io/os: linux` node selector requirement to all components
  - Applied to gpu-process-exporter, node-labeler, container-optimization-data-forwarder, kube-state-metrics, prometheus components, beyla, and k8s-ephemeral-storage-metrics
- Updated gpu-process-exporter dependency from v1.0.0 to v1.1.0
  - Moved `nvidia.com/gpu.present` node selector from hard-coded template to configurable `values.yaml` default
  - Added configurable `tolerations`, `affinity`, and `topologySpreadConstraints` scheduling options
  - Allows users to customize node selector behavior while maintaining GPU node targeting by default

## [1.0.18] - 2026-07-03

### Security
- Updated k8s-ephemeral-storage-metrics dependency to v1.21.0 to resolve CVE-2026-39821

### Changed
- Updated Prometheus chart dependency to v29.14.0

## [1.0.17] - 2026-06-23

### Changed
- Upgraded Prometheus chart dependency to v29.13.0 to overcome KSM sharding issues with v2.19.0

## [1.0.16] - 2026-06-11

### Added
- Added Grafana repository

## [1.0.15] - 2026-06-11

### Added
- Added Beyla as subchart
- Enabled ephemeral storage exporter by default

## [1.0.14] - 2026-06-04

### Added
- Added GPU recording rules for SM utilization metrics

## [1.0.13] - 2026-06-04

### Added
- Added support for native sidecar containers (init containers) in metrics collection
- Added Beyla to metrics scrape endpoints
- Updated ephemeral storage metrics regex

## [1.0.12] - 2026-05-20

### Fixed
- Fixed chart dependencies
- Fixed upgrade path
- Fixed README

## [1.0.11] - 2026-05-08

### Added
- Added gpu-process-exporter chart

### Changed
- Changed logos

## [1.0.10] - 2026-05-08

### Fixed
- Closed remaining metrics review items
- Simplified controller metrics relabeling

## [1.0.9] - 2026-05-07

### Added
- Added OCI artifacts support

### Fixed
- Fixed linting issues
- Aligned controller scrape with validated defaults
- Made controller scrape path explicit
- Enforced controller metrics port explicitly
- Tightened controller metrics scraping
- Scoped controller metrics scrape by service

### Documentation
- Clarified controller scrape contract
- Clarified controller metrics scrape behavior and intent

## [1.0.8] - 2026-04-17

### Added
- Allowed controller metrics scraping

### Fixed
- Restored shared scrape labels
- Deduplicated shared endpointslice relabels
- Pinned controller metrics scrape to HTTP
- Made controller metrics scrape explicit HTTP
- Dedicated controller metrics scrape
- Kept controller metrics samples
- Tightened controller metrics allowlist
- Dropped webhook from metrics allowlist

## [1.0.7] - 2026-04-16

### Changed
- Updated kubex-automation-stack dependencies
- Updated k8s-ephemeral-storage-metrics dependency to v1.20.1
- Updated helm lock with new chart version

## [1.0.6] - 2026-03-20

### Added
- Added OpenShift support to kubex-automation-stack
- Added OpenShift overlay install guidance

### Changed
- Updated container optimization data forwarder image
- Aligned kubex-automation-stack OpenShift values and docs

### Documentation
- Updated README to add steps on enabling workload monitoring in OpenShift

## [1.0.5] - 2026-03-19

### Added
- Created values-xsmall.yaml for small k8s clusters

### Changed
- Updated cluster size table in README
- Updated container range for small k8s clusters

## [1.0.4] - 2026-02-20

### Added
- Added ephemeral storage metrics to kubex-automation-stack
- Added Prometheus scrape job for k8s ephemeral storage metrics

### Changed
- Updated k8s-ephemeral-storage-metrics to v1.20.0
- Updated Prometheus relabeling to scrape k8s ephemeral storage metrics

### Fixed
- Resolved README merge markers and clarified subchart descriptions

## [1.0.3] - 2026-02-19

### Added
- Added node-labeler subchart (disabled by default)
- Added events permissions to clusterrole

### Changed
- Bumped kubex chart versions for automation stack

## [1.0.2] - 2026-01-29

### Changed
- Updated chart dependencies
- Updated chart versions

### Fixed
- Applied various fixes during rebranding

## [1.0.1] - 2025-11-27

### Changed
- Rebranded from Densify to Kubex across all chart components
- Updated branding assets and references

## [1.0.0] - 2025-11-05

### Added
- Improved Kubex Data Collector Helm support
- Values file consolidation
- Support for kubex-automation-controller chart installation

### Changed
- Overrode prometheus-node-exporter scheduling defaults

## [0.9.0] - 2025-01-09

### Changed
- Renamed to Kubex Collection Stack (from Densify Collection Stack)

---

## Component Dependencies

The kubex-automation-stack chart includes the following subcharts:

- **container-optimization-data-forwarder** (v4.x.x) - Data forwarding component
- **prometheus** (v29.x.x) - Metrics collection (conditional: `stack.prometheus.deploy`)
- **beyla** (v1.x.x) - Application observability (conditional: `beyla.enabled`)
- **k8s-ephemeral-storage-metrics** (v1.x.x) - Ephemeral storage metrics (conditional: `k8s-ephemeral-storage-metrics.enabled`)
- **gpu-process-exporter** (v1.x.x) - GPU metrics export (conditional: `gpu-process-exporter.enabled`)
- **node-labeler** (v0.x.x) - Node labeling automation (conditional: `node-labeler.enabled`)

## Support

For issues and questions, contact support@kubex.ai
